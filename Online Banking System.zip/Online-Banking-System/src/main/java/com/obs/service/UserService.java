package com.obs.service;

import java.util.List;

import com.obs.model.User;

public interface UserService {

//	Interfaces automatically treat all methods as public abstract, so you don’t need to write public explicitly.
	
	User registerUser(User user);
	List<User> getAllUsers();
	User getUserByAccountNumber(String accountNumber);
	String deleteUser(String accountNumber);
}
