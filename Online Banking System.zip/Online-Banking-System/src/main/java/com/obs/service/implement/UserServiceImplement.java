package com.obs.service.implement;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.obs.enums.ErrorMessage;
import com.obs.enums.SuccessMessage;
import com.obs.exception.UserNotFoundException;
import com.obs.model.User;
import com.obs.repository.UserRepository;
import com.obs.service.UserService;

@Service
public class UserServiceImplement implements UserService{

//	Field Injection
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public User registerUser(User user) {
		final Random random = new Random();
		String accountNumber;
		
		do {
			accountNumber = "OBS" + String.valueOf(random.nextInt(900000) + 100000);	// Generate a 6-digit number
		}
		while(userRepository.existsByAccountNumber(accountNumber));	// Check if account number exists
		
		user.setAccountNumber(accountNumber);
		return userRepository.save(user);
	}
	
	@Override
	public List<User> getAllUsers(){
		return userRepository.findAll();
	}
	
	@Override
	public User getUserByAccountNumber(String accountNumber) {
		return userRepository.findByAccountNumber(accountNumber)
				.orElseThrow(() -> new UserNotFoundException(ErrorMessage.USER_NOT_FOUND.getMessage() + accountNumber));
	}
	
	@Override
	public String deleteUser(String accountNumber) {
		User user = userRepository.findByAccountNumber(accountNumber)
			.orElseThrow(() -> new UserNotFoundException(ErrorMessage.USER_NOT_FOUND.getMessage() + accountNumber));
		
		userRepository.delete(user);
		return SuccessMessage.USER_DELETED.getMessage();
	}
}
