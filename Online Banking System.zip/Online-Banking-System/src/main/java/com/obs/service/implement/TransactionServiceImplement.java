package com.obs.service.implement;

import java.util.List;

import org.springframework.stereotype.Service;

import com.obs.dto.TransferRequest;
import com.obs.exception.InsufficientBalanceException;
import com.obs.exception.InvalidAmountException;
import com.obs.exception.UserNotFoundException;
import com.obs.model.Transaction;
import com.obs.enums.ErrorMessage;
import com.obs.enums.SuccessMessage;
import com.obs.enums.TransactionType;
import com.obs.model.User;
import com.obs.repository.TransactionRepository;
import com.obs.repository.UserRepository;
import com.obs.service.TransactionService;

@Service
public class TransactionServiceImplement implements TransactionService{

//	Since your TransactionServiceImplement class has only one constructor, you can omit @Autowired
	private UserRepository userRepository;
	private TransactionRepository transactionRepository;

//	Constructor Injection
	public TransactionServiceImplement(UserRepository userRepository, TransactionRepository transactionRepository) {
		this.userRepository = userRepository;
		this.transactionRepository = transactionRepository;
	}
	
	@Override
	public Transaction depositMoney(String accountNumber, Double amount) {
		User user = userRepository.findByAccountNumber(accountNumber)
				.orElseThrow(() -> new UserNotFoundException(ErrorMessage.USER_NOT_FOUND.getMessage() + accountNumber));
		
		if(amount < 1) {
			throw new InvalidAmountException(ErrorMessage.INVALID_DEPOSIT_AMOUNT.getMessage());
		}
		
		user.setBalance(user.getBalance() + amount);
		userRepository.save(user);
		
		return transactionRepository.save(new Transaction(accountNumber, amount, TransactionType.DEPOSIT));
	}
	
	@Override
	public Transaction withdrawMoney(String accountNumber, Double amount) {
		User user = userRepository.findByAccountNumber(accountNumber)
				.orElseThrow(() -> new UserNotFoundException(ErrorMessage.USER_NOT_FOUND.getMessage() + accountNumber));
		
		if(amount < 1) {
			throw new InvalidAmountException(ErrorMessage.INVALID_WITHDRAW_AMOUNT.getMessage());
		}
		
		if(user.getBalance() < amount) {
			throw new InsufficientBalanceException(ErrorMessage.INSUFFICIENT_BALANCE.getMessage());
		}
		
		user.setBalance(user.getBalance() - amount);
		userRepository.save(user);
		
		return transactionRepository.save(new Transaction(accountNumber, -amount, TransactionType.WITHDRAWAL));
	}
	
	@Override
	public String transferMoney(TransferRequest transferRequest) {
		User sender = userRepository.findByAccountNumber(transferRequest.getSenderAccountNumber())
				.orElseThrow(() -> new UserNotFoundException(ErrorMessage.SENDER_NOT_FOUND.getMessage()));
		
		User receiver = userRepository.findByAccountNumber(transferRequest.getReceiverAccountNumber())
				.orElseThrow(() -> new UserNotFoundException(ErrorMessage.RECEIVER_NOT_FOUND.getMessage()));
		
		if(sender.getBalance() < transferRequest.getAmount()) {
			throw new InsufficientBalanceException(ErrorMessage.INSUFFICIENT_BALANCE.getMessage());
		}
		
		if(transferRequest.getAmount() < 1) {
			throw new InvalidAmountException(ErrorMessage.INVALID_TRANSFER_AMOUNT.getMessage());
		}
		
		// Deduct from sender
		sender.setBalance(sender.getBalance() - transferRequest.getAmount());
		
		// Add to receiver
		receiver.setBalance(receiver.getBalance() + transferRequest.getAmount());
		
		// Save updated balances
		userRepository.save(sender);
		userRepository.save(receiver);
		
		// Save and store the TransactionHistory for both sender and receiver
		transactionRepository.save(new Transaction(sender.getAccountNumber(), transferRequest.getSenderAccountNumber(), transferRequest.getReceiverAccountNumber(),
				-transferRequest.getAmount(), TransactionType.TRANSFER));
		
		transactionRepository.save(new Transaction(receiver.getAccountNumber(), transferRequest.getSenderAccountNumber(), transferRequest.getReceiverAccountNumber(),
				transferRequest.getAmount(), TransactionType.TRANSFER));
		
		return SuccessMessage.TRANSFER_SUCCESS.getMessage();
	}
	
	@Override
	public List<Transaction> getAllTransactionHistory() {
		return transactionRepository.findAll();
	}
	
	@Override
	public List<Transaction> getTransactionHistoryByAccountNumber(String accountNumber) {
		userRepository.findByAccountNumber(accountNumber)
		.orElseThrow(() -> new UserNotFoundException(ErrorMessage.USER_NOT_FOUND.getMessage() + accountNumber));

		return transactionRepository.findByAccountNumber(accountNumber);
	}
}
