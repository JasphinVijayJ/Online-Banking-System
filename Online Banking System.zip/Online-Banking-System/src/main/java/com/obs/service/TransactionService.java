package com.obs.service;

import java.util.List;

import com.obs.dto.TransferRequest;
import com.obs.model.Transaction;

public interface TransactionService {

//	Interfaces automatically treat all methods as public abstract, so you don’t need to write public explicitly.
	
	Transaction depositMoney(String accountNumber, Double amount);
	Transaction withdrawMoney(String accountNumber, Double amount);
	String transferMoney(TransferRequest transferRequest);
	List<Transaction> getAllTransactionHistory();
	List<Transaction> getTransactionHistoryByAccountNumber(String accountNumber);
}
