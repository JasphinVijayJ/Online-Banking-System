package com.obs.model;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.obs.enums.TransactionType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "transactions")
@JsonInclude(JsonInclude.Include.NON_NULL)	// This ensures null fields will not be included in the JSON response.
public class Transaction {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotNull(message = "AccountNumber is mandatory")
	@Column(nullable = false)
	private String accountNumber;
	
	@DecimalMin(value = "-10000000.0", message = "Minimum balance should not exceed -1 crore")
	@DecimalMax(value = "10000000.0", message = "Maximum balance should not exceed 1 crore")
	@Column(nullable = false)
	private Double amount;
	
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private TransactionType transactionType;
	
	@Column(nullable = false, updatable = false)
	private LocalDateTime transactionDate;
	
//	For transferMoney transactions
	@Column(nullable = true)
	private String senderAccountNumber;
	
	@Column(nullable = true)
	private String receiverAccountNumber;
	
//	----------------------------------------
	@PrePersist
	public void generated() {
		this.transactionDate = LocalDateTime.now();
	}
	
//	----------------------------------------
	public Transaction() {
//		Default Constructor
	}

	// Constructor for Deposit & Withdrawal
	public Transaction(String accountNumber, Double amount, TransactionType transactionType) {
		this.accountNumber = accountNumber;
		this.amount = amount;
		this.transactionType = transactionType;
	}

	// Constructor for Transfer
	public Transaction(String accountNumber, String senderAccountNumber, String receiverAccountNumber, Double amount, TransactionType transactionType) {
		this.accountNumber = accountNumber;
		this.senderAccountNumber = senderAccountNumber;
		this.receiverAccountNumber = receiverAccountNumber;
		this.amount = amount;
		this.transactionType = transactionType;

	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public TransactionType getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(TransactionType transactionType) {
		this.transactionType = transactionType;
	}

	public LocalDateTime getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(LocalDateTime transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getSenderAccountNumber() {
		return senderAccountNumber;
	}

	public void setSenderAccountNumber(String senderAccountNumber) {
		this.senderAccountNumber = senderAccountNumber;
	}

	public String getReceiverAccountNumber() {
		return receiverAccountNumber;
	}

	public void setReceiverAccountNumber(String receiverAccountNumber) {
		this.receiverAccountNumber = receiverAccountNumber;
	}
	
}
