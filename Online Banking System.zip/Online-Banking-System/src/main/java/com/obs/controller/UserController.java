package com.obs.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.obs.model.User;
import com.obs.service.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/obs/users")
public class UserController {

//	Since your UserController class has only one constructor, you can omit @Autowired
	private final UserService userService;
	
//	Constructor Injection
	public UserController(UserService userService) {
		this.userService = userService;
	}
	
	@PostMapping("/register")
	public ResponseEntity<User> registerUser(@Valid @RequestBody User user) {
		return ResponseEntity.status(HttpStatus.CREATED).body(userService.registerUser(user));
	}
	
	@GetMapping("/allUsers")
	public ResponseEntity<List<User>> getAllUsers(){
		return ResponseEntity.ok(userService.getAllUsers());
	}
	
	@GetMapping("/{accountNumber}")
	public ResponseEntity<User> getUserByAccountNumber(@PathVariable String accountNumber) {
		return ResponseEntity.ok(userService.getUserByAccountNumber(accountNumber));
	}
	
	@DeleteMapping("/{accountNumber}")
	public ResponseEntity<String> deleteUser(@PathVariable String accountNumber) {
		return ResponseEntity.ok(userService.deleteUser(accountNumber));
	}
}
