package com.obs.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.obs.dto.TransferRequest;
import com.obs.model.Transaction;
import com.obs.service.TransactionService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/obs/transactions")
public class TransactionController {

//	Since your TransactionController class has only one constructor, you can omit @Autowired
	private TransactionService transactionService;
	
//	Constructor Injection
	public TransactionController(TransactionService transactionService) {
		this.transactionService = transactionService;
	}
	
	@PostMapping("/deposit/{accountNumber}/{amount}")
	public ResponseEntity<Transaction> depositMoney(@PathVariable String accountNumber, @PathVariable Double amount) {
		return ResponseEntity.ok(transactionService.depositMoney(accountNumber, amount));
	}
	
	@PostMapping("/withdraw")
	public ResponseEntity<Transaction> withdrawMoney(@Valid @RequestBody Transaction transaction) {
		return ResponseEntity.ok(transactionService.withdrawMoney(transaction.getAccountNumber(), transaction.getAmount()));
	}
	
	@PostMapping("/transfer")
	public ResponseEntity<String> transferMoney(@Valid @RequestBody TransferRequest transferRequest) {
		return ResponseEntity.ok(transactionService.transferMoney(transferRequest));
	}
	
	@GetMapping("/allTransactions")
	public ResponseEntity<List<Transaction>> getAllTransactionHistory() {
		return ResponseEntity.ok(transactionService.getAllTransactionHistory());
	}
	
	@GetMapping("/{accountNumber}")
	public ResponseEntity<List<Transaction>> getTransactionHistoryByAccountNumber(@PathVariable String accountNumber) {
		return ResponseEntity.ok(transactionService.getTransactionHistoryByAccountNumber(accountNumber));
	}
}
