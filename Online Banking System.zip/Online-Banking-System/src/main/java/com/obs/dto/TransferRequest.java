package com.obs.dto;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class TransferRequest {

//	DTO (Data Transfer Object) to handle the request.
	@NotBlank(message = "Sender account number is required")
	private String senderAccountNumber;
	
	@NotBlank(message = "Receiver account number is required")
	private String receiverAccountNumber;
	
	@NotNull(message = "Amount cannot be null")
	@DecimalMax(value = "10000000.0", message = "Maximum balance should not exceed 1 crore")
	private Double amount;
	
//	Getter and Setter
	public String getSenderAccountNumber() {
		return senderAccountNumber;
	}
	public void setSenderAccountNumber(String senderAccountNumber) {
		this.senderAccountNumber = senderAccountNumber;
	}
	public String getReceiverAccountNumber() {
		return receiverAccountNumber;
	}
	public void setReceiverAccountNumber(String receiverAccountNumber) {
		this.receiverAccountNumber = receiverAccountNumber;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
}
