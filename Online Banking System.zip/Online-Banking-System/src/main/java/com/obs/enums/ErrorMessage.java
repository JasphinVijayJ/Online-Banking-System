package com.obs.enums;

public enum ErrorMessage {

	USER_NOT_FOUND("User account does not exist with Account number: "),
	INVALID_DEPOSIT_AMOUNT("Deposit amount must be greater than one or equal to one."),
	INVALID_WITHDRAW_AMOUNT("Withdrawal amount must be greater than one or equal to one."),
	INSUFFICIENT_BALANCE("Insufficient balance in account."),
	SENDER_NOT_FOUND("Sender account does not exist."),
	RECEIVER_NOT_FOUND("Receiver account does not exist."),
	INVALID_TRANSFER_AMOUNT("Transfer amount must be greater than one or equal to one.");
	
	private final String message;
	
	ErrorMessage(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}
}
