package com.obs.enums;

public enum TransactionType {
	DEPOSIT, WITHDRAWAL, TRANSFER
}
