package com.obs.enums;

public enum SuccessMessage {
	
	USER_DELETED("User Account deleted successfully."),
	TRANSFER_SUCCESS("Money Transfer Successfully.");

	private final String message;
	
	SuccessMessage(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}
}
